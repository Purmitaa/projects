�
 V  �   _           	      -           >�          Y��#��{�>�0���        �         �                                                                                                 InnoDB      ��                                                                                                                                                                                                                                                                 n   _ 7         P          (    �   -     
 +  @   -     
 /  �        
 3  �        ( 7   �   -  �item_name�item_number�quantity�item_cost�description� 