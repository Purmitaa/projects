package Mine;
import java.util.*;
class Sales
{
    
    String name;int no,min_price,Scharge;int Discount ;int days;
    void Entry()
    {
     
        final Scanner input = new Scanner(System.in);

        System.out.println("Product Name: ");
        name = input.nextLine();
        System.out.println("What is your minimum order: ");
        no = input.nextInt();
        System.out.println("what is the price for the minimum order");
        min_price = input.nextInt();
        System.out.println("How much do you charge for samples: ");
        Scharge = input.nextInt();
        System.out.println("What are the usual Discount you provide for Bulk order: ");
        Discount = input.nextInt();
        System.out.println("Usually,Within how many days do you deliver the placed order ?  ");
        days = input.nextInt();

    }

    void display() {
        System.out.println("Product:  " + name);
        System.out.println("Minimum Order :  " + no);
        System.out.println("Price for the Minimum order:" + min_price + "Rupees");
        System.out.println("Price for Samples: " + Scharge + "Rupees");
        System.out.println("Usual Discount: " + Discount + "%");
        System.out.println("Expected Days of delivery:Minimum " + days + "Days");

    }

}


  public  class producer_produce
    {
        String str;
        public void produce()
        {
        final Scanner input = new Scanner(System.in);
        System.out.println("What kind of products do you produce or sell??");
        str=input.nextLine();
        System.out.println("Then Enter the number of the kinds of products :");
        int n = input.nextInt();
    Sales[]Product;
    Product=new Sales[n];
    for(int i = 0;i<n;i++)
        {
            Product[i] = new Sales();
            Product[i].Entry();

        }
        for(int i = 0;i<n;i++)
        {
            System.out.println("\n");
            Product[i].display();

        }
    }

    }

