package Project;

import java.util.Scanner;

//GETTING CUSTOMER DETAILS
public class consumer_info{
public  consumer_info()
  {
    info();
  }

  public void info(){
  final Scanner in=new Scanner (System.in);
  int n;
System.out.println("Enter your user id: ");
String name=in.next();
System.out.println("Enter your password: ");
n=in.nextInt();
System.out.println("Enter your address: ");
String address=in.next();
System.out.println("Enter your city: ");
String city=in.next();
System.out.println("Enter your contact no: ");
int contact=in.nextInt();
System.out.println("Enter your email address: ");
String email_id=in.next();
System.out.println("\n------------------------");
System.out.println("\nCustomer Details:");
System.out.println("USER ID: " + name);
System.out.println("ADDRESS: " + address);
System.out.println("CITY: " + city);
System.out.println("CONTACT NO: " + contact);
System.out.println("\n---------------------------");

}
}




