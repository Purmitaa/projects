package Mine;


import java.util.*;
import java.lang.*;



class Trims
{

    int[] t= new int[7];
    int[] t_amt=new int[7];
    

    Trims()
    {
       
        trims();
      
       

        
    }
    

    void trims()
    {
        
        System.out.println("_________________________________________");
        System.out.println("|Material\t\t|  Rate(pp)     |");
        System.out.println("_________________________________________");
        System.out.println("|1. Button\t\t|\t4\t| ");
        System.out.println("_________________________________________");
        System.out.println("|2. Label\t\t|\t12\t| ");
        System.out.println("_________________________________________");
        System.out.println("|3. Zipper\t\t|\t6\t|");
        System.out.println("_________________________________________");
        System.out.println("|4.Buckle \t\t|\t20\t|" );
        System.out.println("_________________________________________");
        System.out.println("|5. Elastic\t\t|\t9\t|");
        System.out.println("_________________________________________");
        System.out.println("|6. Thread\t\t|\t10\t|");
        System.out.println("_________________________________________");
        System.out.println("|7. Hook\t\t|\t8\t| ");
        System.out.println("_________________________________________");
        trimbuy();
         }

    void trimbuy()
{   int choice=0,n=1;
    final Scanner input=new Scanner(System.in);
    while(n==1){
        System.out.println("Enter your choice: ");
        choice=input.nextInt();
        switch (choice)
        {
            case 1:
                System.out.println("QTY: ");
                t[0]=input.nextInt();
                break;
            case 2:
                System.out.println("QTY: ");
                t[1]=input.nextInt();
                break;
            case 3:
                System.out.println("QTY: ");
                t[2]=input.nextInt();
                break;
            case 4:
                System.out.println("QTY: ");
                t[3]=input.nextInt();
                break;
            case 5:
                System.out.println("QTY: ");
                t[4]=input.nextInt();
                break;
            case 6:
                System.out.println("QTY: ");
                t[5]=input.nextInt();
                break;
            case 7:
                System.out.println("QTY: ");
                t[6]=input.nextInt();
                break;
            default:
                System.out.println("Invalid Entry");
            
        }
        System.out.println("Do you want to buy more: ");
        n=input.nextInt();


    }
    bill();
    
}
void bill()
{
   
            System.out.println("Bill:\n\n");
            System.out.println("_________________________________________________");
            System.out.println("\tITEM\t\t|QTY\t\t|AMT");
            
            System.out.println("_________________________________________________");
            if(t[0]>0)
                {
                    System.out.println("\tButton\t\t|"+t[0]+"\t\t|"+(t[0]*4)+"\t|");
                System.out.println("_______________________________________________");
                }
            if(t[1]>0)
                {
                    System.out.println("\tLabel\t\t|"+t[1]+"\t\t|"+(t[1]*12)+"\t|");
                System.out.println("_______________________________________________");
                }
            if(t[2]>0)
                {
                    System.out.println("\tZipper\t\t|"+t[2]+"\t\t|"+(t[2]*6)+"\t|");
                System.out.println("______________________________________________");
                }
            if(t[3]>0)
            {
                System.out.println("\tBuckle\t\t|"+t[3]+"\t\t|"+(t[3]*20)+"\t|");
                System.out.println("_________________________________________");
            }
            if(t[4]>0)
               { System.out.println("\tElastic\t\t|"+t[4]+"\t\t|"+(t[4]*9)+"\t|");
               System.out.println("_________________________________________");}

            if(t[5]>0)
                {System.out.println("\tThread\t\t|"+t[5]+"\t\t|"+(t[5]*10)+"\t|");
                System.out.println("_________________________________________");}

            if(t[6]>0)
                {
                    System.out.println("\tHook\t\t|"+t[6]+"\t\t|"+(t[6]*8)+"\t|");
                    System.out.println("_________________________________________");
                }

          

        
    }
}
    class Accesories
    {
    
        int[] t= new int[7];
        int[] t_amt=new int[7];
        
    
        Accesories()
        {
           
            accessories();
          
           
    
            
        }
        
        void accessories()
{       System.out.println("_________________________________________");
        System.out.println("|Material\t\t|  Rate(pp)     |");
        System.out.println("_________________________________________");
        System.out.println("|1. Hanger\t\t|\t12\t| ");
        System.out.println("_________________________________________");
        System.out.println("|2. Poly bag\t\t|\t15\t| ");
        System.out.println("_________________________________________");
        System.out.println("|3. Safety pin\t\t|\t6\t|");
        System.out.println("_________________________________________");
        System.out.println("|4. Neck board\t\t|\t20\t|" );
        System.out.println("_________________________________________");
        System.out.println("|5. Arrow sticker\t|\t5\t|");
        System.out.println("_________________________________________");
        System.out.println("|6. Back board\t\t|\t12\t|");
        System.out.println("_________________________________________");
        System.out.println("|7. Brass pin\t\t|\t8\t| ");
        System.out.println("_________________________________________");
        accbuy();
    }
        
        void accbuy()
    {   int choice=0,n=1;
        final Scanner input=new Scanner(System.in);
        while(n==1)
        {
            System.out.println("Enter your choice: ");
            choice=input.nextInt();
            switch (choice)
            {
                case 1:
                    System.out.println("QTY: ");
                    t[0]=input.nextInt();
                    break;
                case 2:
                    System.out.println("QTY: ");
                    t[1]=input.nextInt();
                    break;
                case 3:
                    System.out.println("QTY: ");
                    t[2]=input.nextInt();
                    break;
                case 4:
                    System.out.println("QTY: ");
                    t[3]=input.nextInt();
                    break;
                case 5:
                    System.out.println("QTY: ");
                    t[4]=input.nextInt();
                    break;
                case 6:
                    System.out.println("QTY: ");
                    t[5]=input.nextInt();
                    break;
                case 7:
                    System.out.println("QTY: ");
                    t[6]=input.nextInt();
                    break;
                default:
                    System.out.println("Invalid Entry");
                
            }
            System.out.println("Do you want to buy more: ");
            n=input.nextInt();
    
    
        }
        bill();
        
    }
    void bill()
    {
       
                System.out.println("Bill:\n\n");
                System.out.println("_________________________________________________");
                System.out.println("\tITEM\t\t|QTY\t\t|AMT");
                
                System.out.println("_________________________________________________");
                if(t[0]>0)
                    {
                        System.out.println("\tHanger\t\t|"+t[0]+"\t\t|"+(t[0]*12)+"\t|");
                    System.out.println("_______________________________________________");
                    }
                if(t[1]>0)
                    {
                        System.out.println("\tPolybag\t\t|"+t[1]+"\t\t|"+(t[1]*15)+"\t|");
                    System.out.println("_______________________________________________");
                    }
                if(t[2]>0)
                    {
                        System.out.println("\tSafetypin\t\t|"+t[2]+"\t\t|"+(t[2]*6)+"\t|");
                    System.out.println("______________________________________________");
                    }
                if(t[3]>0)
                {
                    System.out.println("\tNeckboard\t\t|"+t[3]+"\t\t|"+(t[3]*20)+"\t|");
                    System.out.println("_________________________________________");
                }
                if(t[4]>0)
                   { System.out.println("\tArrowsticker\t\t|"+t[4]+"\t\t|"+(t[4]*5)+"\t|");
                   System.out.println("_________________________________________");}
    
                if(t[5]>0)
                    {System.out.println("\tBackboard\t\t|"+t[5]+"\t\t|"+(t[5]*12)+"\t|");
                    System.out.println("_________________________________________");}
    
                if(t[6]>0)
                    {
                        System.out.println("\tBrasspin\t\t|"+t[6]+"\t\t|"+(t[6]*8)+"\t|");
                        System.out.println("_________________________________________");
                    }
    
                
                
    
            
        }
    
    
    



}

public class producer_buying {
    public void A1() {

        int choice;
        final Scanner input = new Scanner(System.in);
        System.out.println("\nTrims And Accessories\n");
        System.out.println("\n1.Trims\n2.Accessories\n ");
        choice = input.nextInt();
        if (choice == 1) {
            final Trims n = new Trims();
          
        }


        else if (choice == 2) {
            final Accesories p = new Accesories();
         
        } else
            System.out.println("\nInvalid Entry");
    }
}




